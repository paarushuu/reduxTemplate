// import external modules
import { combineReducers } from "redux";
// import internal(own) modules
import calenderReducer from "./calenderReducer";
import emailReducer from "./email/";
// import chatReducer from "./chatReducer";
import chatReducer from "./chat/";
import contactsReducer from "./contacts/";
import todoReducer from "./todo/";
import customizer from "./customizer/";
import login  from '../reducers/login';

import { reducer as toastrReducer } from "react-redux-toastr";

const rootReducer = combineReducers({
  
   toastr: toastrReducer, // <- Mounted at toastr.
   login: login

});

export default rootReducer;
