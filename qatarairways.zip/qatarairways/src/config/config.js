export const config = {
    "apiUrl" : "",
    "AUTHENTICATE_API" : "",
   
};