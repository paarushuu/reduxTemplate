export const config = {
    "GET_USER_API" : "",
    "AUTHENTICATE_API" : "",
   
};