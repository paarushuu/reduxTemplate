import React from "react";

import VisibleContactList from "../../containers/contacts/visibleContactsList";

const App = () => (
   <div>
      <VisibleContactList />
   </div>
);

export default App;
