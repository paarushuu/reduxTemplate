import React from "react";

import VisibleTodoList from "../../containers/todo/visibleTodoList";

const App = () => (
   <div>
      <VisibleTodoList />
   </div>
);

export default App;
