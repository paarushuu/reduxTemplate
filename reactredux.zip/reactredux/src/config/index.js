export const config = {
    "apiUrl" : "http://localhost:3000",
    "AUTHENTICATE_API" : "",
   
};