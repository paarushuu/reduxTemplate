const initState = {
    isLoggedIn: false,
    user: [],
 };
const login = (state = [], action) => {
  switch (action.type) {
    case 'USER_LOGIN':
        return state = []
    default:
      return state
  }
}

export default login
