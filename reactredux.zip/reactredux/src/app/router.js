import React,{Component, Suspense, lazy} from 'react';
import { Router, Route, Switch, Redirect } from 'react-router-dom';
import { connect } from 'react-redux';

import { history } from '../helpers/history';
import { alertActions } from '../redux/actions/alertactions';
import { PrivateRoute } from './PrivateRoute';
import { blankPage } from  '../views/pages/blankPage';
import { Login }  from '../views/Login';
const LazyBlankPage = lazy(() => import("../views/pages/blankPage"));
const LazyLogin  = lazy(() => import('../views/Login'));
class App extends Component {
    constructor(props) {
        super(props);

        // history.listen((location, action) => {
        //     // clear alert on location change
        //     this.props.clearAlerts();
        // });
    }

    render() {
        const { alert } = this.props;
        return (
            <div className="jumbotron">
                <div className="container">
                    <div className="col-sm-8 col-sm-offset-2">
                        
                        <Router history={history}>
                            <Switch>
                                <PrivateRoute exact path="/" component={LazyBlankPage} />
                                <Route path="/login" component={LazyLogin} />
                                <Redirect from="*" to="/" />
                            </Switch>
                        </Router>
                    </div>
                </div>
            </div>
        );
    }
}

function mapState(state) {
    const { alert } = state;
    return { alert };
}

const actionCreators = {
    clearAlerts: alertActions.clear
};

export default connect(mapState, actionCreators)(App);
